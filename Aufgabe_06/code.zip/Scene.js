class Scene {
    constructor(data) {
        this.data = data;
    }

    render() {

    }
}